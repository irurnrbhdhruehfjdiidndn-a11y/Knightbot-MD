import { spawn } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";

export default async function initializeTelegramBot(manager) {
  // ── CONFIG ──────────────────────────────────────────────────────────────────
  const ALLOWED_GROUP_ID = Number(process.env.TG_GROUP_ID) || -1004488652968;
  const GROUP_INVITE_LINK =
    process.env.TG_GROUP_LINK || "https://t.me/Rohan4bot";
  const WA_CHANNEL_LINK =
    process.env.WA_CHANNEL_LINK ||
    "https://whatsapp.com/channel/0029Vb8psS872WToTkVa550i";
  const PAIR_COOLDOWN_MS = 30_000;
  const PAIR_PHOTO_PATH = path.join(process.cwd(), "assets", "rohan04-pairing.png");

  const BOT_TOKEN =
    process.env.BOT_TOKEN_TELEGRAM ||
    process.env.BOT_TOKEN ||
    "8812535254:AAFVt5jvjBP6Fk6oMVuZgb076JGrvnuGU20";

  if (!BOT_TOKEN) {
    console.warn("❌ [bot.js] BOT_TOKEN not set — skipping Telegram bot.");
    return null;
  }

  const RAILWAY_URL =
    process.env.RAILWAY_STATIC_URL || process.env.WEBHOOK_BASE_URL || "";
  const USE_WEBHOOK = Boolean(RAILWAY_URL);

  const { default: TelegramBot } = await import("node-telegram-bot-api");

  const tbot = new TelegramBot(
    BOT_TOKEN,
    USE_WEBHOOK
      ? { polling: false }
      : { polling: { interval: 3000, timeout: 30 } }
  );

  tbot.on("polling_error", (e) =>
    console.error("❗ [bot.js] Polling error:", e?.message || e)
  );
  tbot.on("webhook_error", (e) =>
    console.error("❗ [bot.js] Webhook error:", e?.message || e)
  );

  let botId = null;
  try {
    const me = await tbot.getMe();
    botId = me.id;
    tbot.botId = me.id;
    tbot.botUsername = me.username;
    console.log(
      `🤖 [bot.js] @${me.username} (${me.id}) — mode: ${
        USE_WEBHOOK ? "webhook" : "polling"
      }`
    );
  } catch (e) {
    console.warn("⚠️ [bot.js] getMe failed:", e?.message);
  }

  const pairCooldown = new Map();

  const esc = (s = "") =>
    String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

  function F(text = "") {
    return String(text).replace(/[A-Za-z]/g, (ch) => {
      const c = ch.charCodeAt(0);
      if (c >= 65 && c <= 90) return String.fromCodePoint(0x1d5a0 + (c - 65));
      if (c >= 97 && c <= 122) return String.fromCodePoint(0x1d5ba + (c - 97));
      return ch;
    });
  }

  function isoToFlag(iso) {
    if (!iso || iso.length !== 2) return "🏳️";
    const A = 0x1f1e6;
    return [...iso.toUpperCase()]
      .map((c) => String.fromCodePoint(A + c.charCodeAt(0) - 65))
      .join("");
  }

  function fmtCode(raw) {
    const s = String(raw || "").replace(/\s+/g, "");
    return s.match(/.{1,4}/g)?.join("-") || s;
  }

  function isPrivate(msg) {
    return msg?.chat?.type === "private";
  }

  function isAllowedGroup(msg) {
    try {
      if (!msg?.chat) return false;
      if (msg.chat.type === "private") return false;
      return String(msg.chat.id) === String(ALLOWED_GROUP_ID);
    } catch {
      return false;
    }
  }

  function isAnonymousAdmin(msg) {
    return !!(
      msg?.sender_chat &&
      msg?.chat &&
      String(msg.sender_chat.id) === String(msg.chat.id)
    );
  }

  async function isAdmin(msg) {
    try {
      if (!msg?.chat) return false;
      if (msg.chat.type === "private") return false;
      if (isAnonymousAdmin(msg)) return true;
      if (!msg.from) return false;
      const member = await tbot.getChatMember(msg.chat.id, msg.from.id);
      return member?.status === "creator" || member?.status === "administrator";
    } catch {
      return false;
    }
  }

  function safeReply(chatId, text, opts = {}) {
    return tbot
      .sendMessage(chatId, text, { parse_mode: "HTML", ...opts })
      .catch((e) => {
        console.error("[bot.js] sendMessage failed:", e?.message);
      });
  }

  function safeEdit(chatId, msgId, text, opts = {}) {
    return tbot
      .editMessageText(text, {
        chat_id: chatId,
        message_id: msgId,
        parse_mode: "HTML",
        ...opts,
      })
      .catch(() => {});
  }

  function waitForSessionOpen(sessionId, timeoutMs = 25_000) {
    return new Promise((resolve, reject) => {
      if (manager.isRunning(sessionId)) return resolve();

      const timer = setTimeout(() => {
        manager.removeListener("connected", onConn);
        manager.removeListener("session.deleted", onDel);
        reject(new Error("Connection timeout"));
      }, timeoutMs);

      function onConn(sid) {
        if (sid !== sessionId) return;
        clearTimeout(timer);
        manager.removeListener("connected", onConn);
        manager.removeListener("session.deleted", onDel);
        resolve();
      }
      function onDel(sid) {
        if (sid !== sessionId) return;
        clearTimeout(timer);
        manager.removeListener("connected", onConn);
        manager.removeListener("session.deleted", onDel);
        reject(new Error("Session deleted before connecting"));
      }

      manager.on("connected", onConn);
      manager.on("session.deleted", onDel);
    });
  }

  const CALLING_CODE_MAP = {
    1: { iso: "US", name: "United States/Canada" },
    7: { iso: "RU", name: "Russia/Kazakhstan" },
    20: { iso: "EG", name: "Egypt" },
    27: { iso: "ZA", name: "South Africa" },
    30: { iso: "GR", name: "Greece" },
    31: { iso: "NL", name: "Netherlands" },
    32: { iso: "BE", name: "Belgium" },
    33: { iso: "FR", name: "France" },
    34: { iso: "ES", name: "Spain" },
    36: { iso: "HU", name: "Hungary" },
    39: { iso: "IT", name: "Italy" },
    40: { iso: "RO", name: "Romania" },
    41: { iso: "CH", name: "Switzerland" },
    43: { iso: "AT", name: "Austria" },
    44: { iso: "GB", name: "United Kingdom" },
    45: { iso: "DK", name: "Denmark" },
    46: { iso: "SE", name: "Sweden" },
    47: { iso: "NO", name: "Norway" },
    48: { iso: "PL", name: "Poland" },
    49: { iso: "DE", name: "Germany" },
    51: { iso: "PE", name: "Peru" },
    52: { iso: "MX", name: "Mexico" },
    53: { iso: "CU", name: "Cuba" },
    54: { iso: "AR", name: "Argentina" },
    55: { iso: "BR", name: "Brazil" },
    56: { iso: "CL", name: "Chile" },
    57: { iso: "CO", name: "Colombia" },
    58: { iso: "VE", name: "Venezuela" },
    60: { iso: "MY", name: "Malaysia" },
    61: { iso: "AU", name: "Australia" },
    62: { iso: "ID", name: "Indonesia" },
    63: { iso: "PH", name: "Philippines" },
    64: { iso: "NZ", name: "New Zealand" },
    65: { iso: "SG", name: "Singapore" },
    66: { iso: "TH", name: "Thailand" },
    81: { iso: "JP", name: "Japan" },
    82: { iso: "KR", name: "South Korea" },
    84: { iso: "VN", name: "Vietnam" },
    86: { iso: "CN", name: "China" },
    90: { iso: "TR", name: "Turkey" },
    91: { iso: "IN", name: "India" },
    92: { iso: "PK", name: "Pakistan" },
    93: { iso: "AF", name: "Afghanistan" },
    94: { iso: "LK", name: "Sri Lanka" },
    95: { iso: "MM", name: "Myanmar" },
    98: { iso: "IR", name: "Iran" },
    880: { iso: "BD", name: "Bangladesh" },
    886: { iso: "TW", name: "Taiwan" },
    966: { iso: "SA", name: "Saudi Arabia" },
    971: { iso: "AE", name: "UAE" },
  };

  const SORTED_CODES = Object.keys(CALLING_CODE_MAP)
    .map(Number)
    .sort((a, b) => String(b).length - String(a).length || b - a);

  function detectCountry(digits) {
    if (!digits) return null;
    if (digits.startsWith("00")) digits = digits.slice(2);
    for (const code of SORTED_CODES) {
      if (digits.startsWith(String(code))) {
        const info = CALLING_CODE_MAP[code];
        return { callingCode: code, iso: info.iso, name: info.name };
      }
    }
    return null;
  }

  function buildPairSuccessMessage(rawArg, rawCode, countryInfo) {
    const code = fmtCode(rawCode);
    const flag = countryInfo ? isoToFlag(countryInfo.iso) : "🌍";
    const country = countryInfo
      ? `${flag} <b>${esc(countryInfo.name)}</b> (+${countryInfo.callingCode})`
      : `🌍 <i>Country unknown</i>`;

    const text = [
      `   🔐 ${F("PAIR CODE READY")}`,
      ``,
      `📱 ${F("Number:")}  <code>${esc(rawArg)}</code>`,
      `🌐 ${F("Country:")} ${country}`,
      ``,
      `┌─────────────┐`,
      `│  🔑 <b><code>${esc(code)}</code></b>`,
      `└─────────────┘`,
      ``,
      `📌 ${F("How to link:")}`,
      `<i>WhatsApp → Settings → Linked Devices</i>`,
      `<i>→ Link a Device → Enter code above</i>`,
      ``,
      `⏰ <i>Code expires in ~60 seconds</i>`,
    ].join("\n");

    const reply_markup = {
      inline_keyboard: [
        [
          {
            text: `${code}`,
            copy_text: { text: code },
          },
        ],
        [
          {
            text: "WA Channel",
            url: WA_CHANNEL_LINK,
          },
        ],
      ],
    };

    return { text, reply_markup };
  }

  function buildHelpMessage() {
    return [
      `👤 ${F("User Commands")}`,
      `┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄`,
      `📌 <code>/start</code>  — Welcome message`,
      `📌 <code>/pair +91XXXXXXXXXX</code> — Generate WhatsApp pair code`,
      `📌 <code>/ping</code>  — Check bot latency`,
      `📌 <code>/help</code>  — Show this menu`,
      ``,
      `👑 ${F("Admin Commands")}`,
      `┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄`,
      `📌 <code>/sessions</code> — View connected WhatsApp sessions`,
      `📌 <code>/status</code> — System status & active connections`,
      `📌 <code>/stop SID</code> — Stop a session`,
      `📌 <code>/logout SID</code> — Delete session credentials`,
      `📌 <code>/restart SID</code> — Restart a session`,
      `📌 <code>/s SID code</code> — Execute code on session`,
      `📌 <code>/as code</code> — Execute on all active sessions`,
      `📌 <code>/d command</code> — Run shell command`,
    ].join("\n");
  }

  async function doPair(chatId, rawArg, replyToId) {
    const digits = rawArg.replace(/\D/g, "");
    const countryInfo = detectCountry(digits);
    const flag = countryInfo ? isoToFlag(countryInfo.iso) : "☁️";
    const countryName = countryInfo?.name || "Unknown";

    const loadingMsg = await safeReply(
      chatId,
      [
        `⏳ ${F("Generating Pair Code...")}`,
        ``,
        `📱 ${F("Number:")} <code>${esc(rawArg)}</code>`,
        countryInfo
          ? `${flag} ${esc(countryName)} (+${countryInfo.callingCode})`
          : `🌍 <i>Country not detected — trying anyway</i>`,
        ``,
        `🔄 <i>Please wait a moment...</i>`,
      ].join("\n"),
      { reply_to_message_id: replyToId }
    );

    let rawCode = null;
    try {
      const sock = await manager.start(digits);
      if (!sock) throw new Error("Socket creation failed");

      try {
        await waitForSessionOpen(digits, 25_000);
      } catch (e) {
        console.warn(`[bot.js] waitForSessionOpen warning: ${e.message}`);
      }

      if (typeof sock.requestPairingCode !== "function") {
        throw new Error("Pairing API not supported by current socket version");
      }

      await new Promise((resolve) => setTimeout(resolve, 2000));
      rawCode = await sock.requestPairingCode(digits);
    } catch (err) {
      try {
        await tbot.deleteMessage(chatId, loadingMsg?.message_id);
      } catch {}
      return safeReply(
        chatId,
        [
          `   ❌ ${F("PAIR FAILED")}`,
          ``,
          `📱 ${F("Number:")} <code>${esc(rawArg)}</code>`,
          `💬 ${F("Reason:")} <i>${esc(String(err?.message || err))}</i>`,
          ``,
          `🔁 <i>Try again with /pair +${esc(digits)}</i>`,
        ].join("\n"),
        { reply_to_message_id: replyToId }
      );
    }

    try {
      await tbot.deleteMessage(chatId, loadingMsg?.message_id);
    } catch {}

    if (!rawCode) {
      return safeReply(
        chatId,
        `❌ ${F("No pair code returned — please try again.")}`,
        { reply_to_message_id: replyToId }
      );
    }

    try {
      if (fs.existsSync(PAIR_PHOTO_PATH)) {
        await tbot.sendPhoto(chatId, PAIR_PHOTO_PATH, {
          reply_to_message_id: replyToId,
        });
      }
    } catch (e) {}

    const { text, reply_markup } = buildPairSuccessMessage(
      rawArg,
      rawCode,
      countryInfo
    );

    const pairMsg = await safeReply(chatId, text, {
      reply_to_message_id: replyToId,
      reply_markup,
      disable_web_page_preview: true,
    });

    // ── Live Status Watcher (কানেক্টেড হওয়ার স্ট্যাটাস রিয়েলটাইমে আপডেট করার অংশ) ──
    if (pairMsg?.message_id) {
      const WATCH_TIMEOUT_MS = 5 * 60 * 1000;
      const msgId = pairMsg.message_id;
      const displayNum = `+${digits}`;

      const connectedText = [
        `  ❤️‍🩹 ${F("BOT CONNECTED!")}`,
        ``,
        `✅ ${F("Successfully linked!")}`,
        ``,
        `📱 ${F("Number:")}  <code>${esc(displayNum)}</code>`,
        countryInfo
          ? `${flag} <b>${esc(countryInfo.name)}</b> (+${countryInfo.callingCode})`
          : `🌍 <i>Country unknown</i>`,
      ].join("\n");

      const failedText = [
        `  😴 ${F("PAIR UNSUCCESSFUL")}`,
        ``,
        `⏰ ${F("Timed out — code was not used.")}`,
        ``,
        `📱 ${F("Number:")}  <code>${esc(displayNum)}</code>`,
        ``,
        `🔁 ${F("Please try again:")} <code>/pair ${esc(displayNum)}</code>`,
      ].join("\n");

      (async () => {
        try {
          await new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
              manager.removeListener("connected", onConn);
              manager.removeListener("session.deleted", onDel);
              reject(new Error("timeout"));
            }, WATCH_TIMEOUT_MS);

            function onConn(sid) {
              if (sid !== digits) return;
              clearTimeout(timer);
              manager.removeListener("connected", onConn);
              manager.removeListener("session.deleted", onDel);
              resolve("connected");
            }
            function onDel(sid) {
              if (sid !== digits) return;
              clearTimeout(timer);
              manager.removeListener("connected", onConn);
              manager.removeListener("session.deleted", onDel);
              reject(new Error("deleted"));
            }

            manager.on("connected", onConn);
            manager.on("session.deleted", onDel);
          });

          await safeEdit(chatId, msgId, connectedText, {
            reply_markup: { inline_keyboard: [[{ text: "WA Channel", url: WA_CHANNEL_LINK }]] },
            disable_web_page_preview: true,
          });
        } catch (reason) {
          await safeEdit(chatId, msgId, failedText, {
            reply_markup: { inline_keyboard: [[{ text: "WA Channel", url: WA_CHANNEL_LINK }]] },
            disable_web_page_preview: true,
          });
        }
      })();
    }

    return pairMsg;
  }

  tbot.on("new_chat_members", async (msg) => {
    try {
      if (!msg?.new_chat_members) return;
      if (!botId) return;
      const addedBot = msg.new_chat_members.some((m) => m.id === botId);
      if (!addedBot) return;

      if (!isAllowedGroup(msg)) {
        await safeReply(
          msg.chat.id,
          `❌ <b>${F("Unauthorized Group")}</b>\n\n${F(
            "This bot only works in the official group."
          )}\n\n👉 ${GROUP_INVITE_LINK}`
        );
        await tbot.leaveChat(msg.chat.id).catch(() => {});
      } else {
        await safeReply(
          msg.chat.id,
          `🎉 <b>${F("Bot is ready!")}</b> 🌸\n\nUse /help to see available commands.`
        );
      }
    } catch (e) {}
  });

  async function redirectToGroup(chatId, replyToId) {
    return tbot
      .sendMessage(
        chatId,
        [
          `🌸 <b>${F("Group Only Feature")}</b>`,
          ``,
          `👉 ${F("This command works only in the official group.")}`,
        ].join("\n"),
        {
          parse_mode: "HTML",
          reply_to_message_id: replyToId,
          reply_markup: {
            inline_keyboard: [
              [
                {
                  text: "🌷 Join Official Group",
                  url: GROUP_INVITE_LINK,
                },
              ],
            ],
          },
        }
      )
      .catch(() => {});
  }

  function parseCmd(msg) {
    if (!msg?.text) return null;
    const entities = msg.entities || [];
    if (entities.length > 0) {
      const first = entities[0];
      if (first.type === "bot_command" && first.offset === 0) {
        const raw = msg.text.slice(0, first.length);
        const cmd = raw.split(/[@\s]/)[0].replace(/^\//, "").toLowerCase();
        const args = msg.text.slice(first.length).trim();
        return { cmd, args };
      }
    }
    if (!msg.text.startsWith("/")) return null;
    const [rawCmd, ...rest] = msg.text.trim().split(/\s+/);
    return {
      cmd: rawCmd.split("@")[0].replace(/^\//, "").toLowerCase(),
      args: rest.join(" ").trim(),
    };
  }

  async function handleCommand(msg) {
    const parsed = parseCmd(msg);
    if (!parsed) return;
    const { cmd, args } = parsed;
    const chatId = msg.chat.id;
    const replyId = msg.message_id;

    if (cmd === "start") {
      if (isPrivate(msg)) return redirectToGroup(chatId, replyId);
      if (!isAllowedGroup(msg)) return;
      return safeReply(
        chatId,
        [
          `   ✨ ${F("ROHAN-04 BOT")}`,
          ``,
          `🍉 ${F("Fast & secure WhatsApp pairing.")}`,
          ``,
          `📌 ${F("Generate your pair code:")}`,
          `<code>/pair +91700393888</code>`,
          ``,
          `📖 ${F("See all commands:")} <code>/help</code>`,
        ].join("\n"),
        { reply_to_message_id: replyId }
      );
    }

    if (cmd === "help") {
      if (isPrivate(msg)) return redirectToGroup(chatId, replyId);
      if (!isAllowedGroup(msg)) return;
      return safeReply(chatId, buildHelpMessage(), {
        reply_to_message_id: replyId,
      });
    }

    if (cmd === "ping") {
      if (isPrivate(msg)) return redirectToGroup(chatId, replyId);
      if (!isAllowedGroup(msg)) return;
      const start = Date.now();
      const m = await safeReply(chatId, "🏓 Pong!", {
        reply_to_message_id: replyId,
      });
      const ms = Date.now() - start;
      return safeEdit(chatId, m.message_id, `🏓 <b>Pong!</b>\n⚡ <b>${ms}ms</b>`);
    }

    if (cmd === "pair") {
      if (isPrivate(msg)) return redirectToGroup(chatId, replyId);
      if (!isAllowedGroup(msg)) return;

      if (!args) {
        return safeReply(
          chatId,
          `🛑 <b>${F("Usage")}</b>\n<code>/pair +917074420859</code>`,
          { reply_to_message_id: replyId }
        );
      }

      const digits = args.replace(/\D/g, "");
      if (!digits || digits.length < 6) {
        return safeReply(chatId, `❌ ${F("Invalid number.")}`, {
          reply_to_message_id: replyId,
        });
      }

      const userId = msg.from?.id || msg.sender_chat?.id;
      const lastPair = pairCooldown.get(userId) || 0;
      const remaining = PAIR_COOLDOWN_MS - (Date.now() - lastPair);
      if (remaining > 0) {
        return safeReply(
          chatId,
          `⏳ ${F("Please wait")} <b>${Math.ceil(remaining / 1000)}s</b>`,
          { reply_to_message_id: replyId }
        );
      }
      pairCooldown.set(userId, Date.now());

      return doPair(chatId, args, replyId);
    }

    // ── /sessions (কতগুলি এবং কোন সেশন কানেক্টেড আছে দেখার অপশন) ────────────────
    if (cmd === "sessions" || cmd === "session") {
      if (!isAllowedGroup(msg)) return;
      if (!(await isAdmin(msg))) {
        return safeReply(chatId, `🚫 <b>${F("Admins Only")}</b>`, { reply_to_message_id: replyId });
      }

      const conns = manager.getAllConnections?.() || [];
      if (conns.length === 0) {
        return safeReply(
          chatId,
          `🌙 <b>${F("No Active Sessions")}</b>\n\n${F("No sessions are currently registered.")}`,
          { reply_to_message_id: replyId }
        );
      }

      const connected = conns.filter((c) => c.healthy).length;
      const disconnected = conns.length - connected;

      let text = [
        `   🧩 ${F("SESSION OVERVIEW")}`,
        ``,
        `📊 Total: <b>${conns.length}</b>  🟢 Online: <b>${connected}</b>  🔴 Offline: <b>${disconnected}</b>`,
        ``,
      ].join("\n");

      conns.forEach((c, i) => {
        const sid = c.sessionId || c.file_path || "unknown";
        const user =
          c.connection?.user?.name ||
          c.connection?.user?.id?.split(":")?.[0] ||
          "—";
        const dot = c.healthy ? "🟢" : "🔴";
        const stat = c.status || (c.healthy ? "connected" : "disconnected");
        text += `${dot} <b>${i + 1}.</b> <code>${esc(sid)}</code>\n`;
        text += `    👤 ${esc(user)} · <i>${stat}</i>\n\n`;
      });

      return safeReply(chatId, text, {
        reply_to_message_id: replyId,
        disable_web_page_preview: true,
      });
    }

    // ── /status (বটের মেমোরি ও কানেক্টেড সেশন এর কাউন্ট) ───────────────────────
    if (cmd === "status") {
      if (!isAllowedGroup(msg)) return;
      if (!(await isAdmin(msg))) {
        return safeReply(chatId, `🚫 <b>${F("Admins Only")}</b>`, { reply_to_message_id: replyId });
      }

      const conns = manager.getAllConnections?.() || [];
      const online = conns.filter((c) => c.healthy).length;
      const upSec = Math.floor(process.uptime());
      const uptimeFmt = `${Math.floor(upSec / 3600)}h ${Math.floor((upSec % 3600) / 60)}m ${upSec % 60}s`;
      const memMb = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);

      return safeReply(
        chatId,
        [
          `   📊 ${F("BOT STATUS")}`,
          ``,
          `⏰ ${F("Uptime:")}     <code>${uptimeFmt}</code>`,
          `💾 ${F("Memory:")}    <code>${memMb} MB</code>`,
          `🔌 ${F("Sessions:")}  <b>${conns.length}</b> total  •  🟢 <b>${online}</b> online`,
          `🖥️ ${F("Platform:")}  <code>${process.platform}</code>`,
          `📦 ${F("Node.js:")}   <code>${process.version}</code>`,
        ].join("\n"),
        { reply_to_message_id: replyId }
      );
    }

    // ── /stop ─────────────────────────────────────────────────────────────
    if (cmd === "stop") {
      if (!isAllowedGroup(msg) || !(await isAdmin(msg))) return;
      const sid = (args || "").replace(/\D/g, "");
      if (!sid) return safeReply(chatId, `❓ ${F("Usage:")} <code>/stop 91XXXXXXXXXX</code>`, { reply_to_message_id: replyId });

      try {
        await manager.stop(sid);
        return safeReply(chatId, `⏹️ <b>Session Stopped:</b> <code>${esc(sid)}</code>`, { reply_to_message_id: replyId });
      } catch (e) {
        return safeReply(chatId, `❌ Stop failed: <i>${esc(e?.message)}</i>`, { reply_to_message_id: replyId });
      }
    }

    // ── /logout ───────────────────────────────────────────────────────────
    if (cmd === "logout") {
      if (!isAllowedGroup(msg) || !(await isAdmin(msg))) return;
      const sid = (args || "").replace(/\D/g, "");
      if (!sid) return safeReply(chatId, `❓ ${F("Usage:")} <code>/logout 91XXXXXXXXXX</code>`, { reply_to_message_id: replyId });

      try {
        await manager.logout(sid);
        return safeReply(chatId, `🗑️ <b>Session Logged Out:</b> <code>${esc(sid)}</code>`, { reply_to_message_id: replyId });
      } catch (e) {
        return safeReply(chatId, `❌ Logout failed: <i>${esc(e?.message)}</i>`, { reply_to_message_id: replyId });
      }
    }

    // ── /restart ──────────────────────────────────────────────────────────
    if (cmd === "restart") {
      if (!isAllowedGroup(msg) || !(await isAdmin(msg))) return;
      const sid = (args || "").replace(/\D/g, "");
      if (!sid) return safeReply(chatId, `❓ ${F("Usage:")} <code>/restart 91XXXXXXXXXX</code>`, { reply_to_message_id: replyId });

      try {
        await manager.stop(sid);
        await new Promise((r) => setTimeout(r, 1500));
        await manager.start(sid);
        return safeReply(chatId, `🔄 <b>Session Restarted:</b> <code>${esc(sid)}</code>`, { reply_to_message_id: replyId });
      } catch (e) {
        return safeReply(chatId, `❌ Restart failed: <i>${esc(e?.message)}</i>`, { reply_to_message_id: replyId });
      }
    }

    // ── /s (Session script execution) ──────────────────────────────────────
    if (cmd === "s") {
      const spaceIdx = (args || "").indexOf(" ");
      if (spaceIdx === -1) {
        return safeReply(chatId, `❓ Usage: <code>/s 91XXXXXXXXXX sock.user</code>`, { reply_to_message_id: replyId });
      }
      const sid = args.slice(0, spaceIdx).trim().replace(/\D/g, "");
      const code = args.slice(spaceIdx + 1).trim();

      const entry = manager.sessions?.get(sid);
      if (!entry?.sock) {
        return safeReply(chatId, `❌ Session Not Found: <code>${esc(sid)}</code>`, { reply_to_message_id: replyId });
      }

      try {
        const AsyncFn = Object.getPrototypeOf(async function () {}).constructor;
        const fn = new AsyncFn("sock", `return await (${code})`);
        const result = await fn(entry.sock);
        return safeReply(chatId, `✅ <b>Result:</b>\n<pre>${esc(JSON.stringify(result, null, 2))}</pre>`, { reply_to_message_id: replyId });
      } catch (err) {
        return safeReply(chatId, `❌ Error: <code>${esc(err?.message)}</code>`, { reply_to_message_id: replyId });
      }
    }

    // ── /as (Run code on ALL active sessions) ──────────────────────────────
    if (cmd === "as") {
      const code = (args || "").trim();
      if (!code) return safeReply(chatId, `❓ Usage: <code>/as sock.user</code>`, { reply_to_message_id: replyId });

      const allEntries = [...manager.sessions.entries()].filter(
        ([, entry]) => entry?.sock && (entry.healthy || entry.status === "open")
      );

      await Promise.allSettled(
        allEntries.map(async ([, entry]) => {
          const AsyncFn = Object.getPrototypeOf(async function () {}).constructor;
          const fn = new AsyncFn("sock", `return await (${code})`);
          return await fn(entry.sock);
        })
      );

      return safeReply(chatId, `📊 Executed code on <b>${allEntries.length}</b> online sessions.`, { reply_to_message_id: replyId });
    }

    // ── /d (Shell execution - Admin only) ──────────────────────────────────
    if (cmd === "d") {
      if (!(await isAdmin(msg))) return;
      const rawCmd = (args || "").trim();
      if (!rawCmd) return;

      const child = spawn("bash", ["-lc", rawCmd], { env: process.env });
      let output = "";
      child.stdout.on("data", (c) => (output += c));
      child.stderr.on("data", (c) => (output += c));

      child.on("close", () => {
        safeReply(chatId, `<pre>${esc(output.slice(0, 1800) || "Done (no output)")}</pre>`, { reply_to_message_id: replyId });
      });
    }
  }

  tbot.on("message", async (msg) => {
    try {
      await handleCommand(msg);
    } catch (e) {
      console.error("[bot.js] handleCommand error:", e);
    }
  });

  if (USE_WEBHOOK) {
    try {
      const hookPath = `/bot${BOT_TOKEN}`;
      const webhookUrl = `${RAILWAY_URL.replace(/\/$/, "")}${hookPath}`;
      await tbot.setWebHook(webhookUrl);
    } catch (e) {}
  }

  tbot.cleanup = async () => {
    try {
      if (USE_WEBHOOK) await tbot.deleteWebHook().catch(() => {});
      else await tbot.stopPolling().catch(() => {});
    } catch (e) {}
  };

  return tbot;
}